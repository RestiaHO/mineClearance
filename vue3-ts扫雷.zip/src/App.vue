<template>
  <div :style="{height: `${wrapHeight}px`, width: `${wrapWidth}px`}" style="overflow: hidden">
    <HelloWorld msg="Hello Vue 3 + TypeScript + Vite" />
  </div>
</template>

<script setup lang="ts">
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup
import { defineAsyncComponent, onMounted, defineExpose, ref} from 'vue'
const HelloWorld: any = defineAsyncComponent(() => import('./components/HelloWorld.vue'))

let wrapWidth = ref(0)
let wrapHeight = ref(0)

function initPage () {
  wrapWidth.value = window.innerWidth
  wrapHeight.value = window.innerHeight
}

onMounted(() => {
  initPage()
  addEventListener('resize', () => {
    initPage()
  })
})

// 暴露方法
defineExpose({initPage})
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center; */
  color: #2c3e50;
}
</style>
