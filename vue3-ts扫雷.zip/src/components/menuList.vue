<template>
  <a-layout style="height: 100%">
    <a-layout-sider>
      <a-menu theme="dark" mode="inline" style="width: 52px; height: 100%" v-model:selectedKeys="state.selectedKeys">
        <a-menu-item key="1">
          <template #icon>
            <PieChartOutlined />
          </template>
        </a-menu-item>
        <a-menu-item key="2">
          <template #icon>
            <LockOutlined />
          </template>
        </a-menu-item>
      <a-menu-item key="3">
          <template #icon>
            <MacCommandOutlined />
          </template>
        </a-menu-item>
        <a-menu-item key="4">
          <template #icon>
            <LinkOutlined />
          </template>
        </a-menu-item>
      </a-menu> 
    </a-layout-sider>
    <a-layout-content>
      <div style="height: 22px; padding: 0 12px">
        <Nav :tab="state.selectedKeys[0]"/>
      </div>
      <div style="height: calc(100% - 22px); padding: 12px">
        <component :is="Navs[state.selectedKeys[0]]"></component>
      </div>
    </a-layout-content>
  </a-layout>
</template>

<script setup lang="ts">
import {reactive, watch, defineAsyncComponent, markRaw} from 'vue'
import {PieChartOutlined, LockOutlined, MacCommandOutlined, LinkOutlined} from '@ant-design/icons-vue'

const Nav: any = defineAsyncComponent(() => import('./Nav.vue'))
const Tab1: any = markRaw(defineAsyncComponent(() => import('./tab1.vue')))
const Tab2: any = markRaw(defineAsyncComponent(() => import('./tab2.vue')))
const state = reactive({
    selectedKeys: ['1']
})

const Navs = reactive({
  '1': Tab1,
  '2': Tab2
})

watch(
  () => state.selectedKeys,
  (newKey, oldKey) => {
    console.log(newKey, 'newKey', oldKey, 'oldKey')
  }
)

console.log(state.selectedKeys)
</script>

<style scoped>
.ant-layout-sider {
  flex: 0 0 52px !important;
  min-width: 52px !important;
  max-width: 52px !important;
  width: 52px !important;
}
</style>
