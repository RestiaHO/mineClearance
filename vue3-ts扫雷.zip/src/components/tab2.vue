<template>
    <div class="card">
        <div class="card-side front">
        </div>
        <div class="card-side back">
        </div>
    </div>

    <div class="card2">
        <div class="card-side2 front2">
        </div>
        <div class="card-side2 back2">
        </div>
    </div>
</template>

<script lang="ts" setup>

</script>

<style scoped>
.card {
  /* perspective: 150rem; */
  position: relative;
  height: 180px;
  width: 120px;
  max-width: 120px;
  margin: 2rem;
  box-shadow: none;
  background: none;
}

.card-side {
  height: 100%;
  border-radius: 2px;
  transition: all 0.8s ease;
  backface-visibility: hidden;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  padding:2rem;
  color: white;
  background-size: 100% 100%;
}

.card-side.back {
  transform: rotateY(-180deg);
  background-color: #4158D0;
  /* background-image: linear-gradient(43deg, #4158D0 0%,#C850C0 46%, #FFCC70 100%); */
  background-image: url('../assets/blueEye.jpg');
}

.card-side.front {
  background-color: #0093E9;
  /* background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%); */
  background-image: url('../assets/kabei.jpg');
}

.card:hover .card-side.front {
  transform: rotateY(180deg);
}

.card:hover .card-side.back {
  transform: rotateY(0deg);
}

.card2 {
  /* perspective: 150rem; */
  position: relative;
  height: 120px;
  width: 180px;
  max-width: 180px;
  margin: 2rem;
  box-shadow: none;
  background: none;
}

.card-side2 {
  height: 100%;
  border-radius: 2px;
  transition: all 0.8s ease;
  backface-visibility: hidden;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  padding:2rem;
  color: white;
  background-size: 100% 100%;
}

.card-side2.back2 {
  transform: rotateX(-180deg);
  background-color: #4158D0;
  /* background-image: linear-gradient(43deg, #4158D0 0%,#C850C0 46%, #FFCC70 100%); */
  background-image: url('../assets/blueEye2.jpg');
}

.card-side2.front2 {
  background-color: #0093E9;
  /* background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%); */
  background-image: url('../assets/kabei2.jpg');
}

.card2:hover .card-side2.front2 {
  transform: rotateX(180deg);
}

.card2:hover .card-side2.back2 {
  transform: rotateX(0deg);
}
</style>