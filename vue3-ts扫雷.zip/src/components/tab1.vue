<template>
    <div name="雷区数量">
        设置雷量：
        <a-input placeholder="数量" v-model:value="mineFieldNumber" style="width: 100px; margin-right: 12px"/>
        <a-button @click="start" style="margin-bottom: 12px">start</a-button>
    </div>

    <div name="结果展示">
        <span>{{relax}}</span>
    </div>

    <!-- <div class="border o_box">
        <div v-for="(y, y_i) in array" :key="y_i" class="my_border">
            <div v-for="(x, x_i) in y" :key="x_i" class="border y_box">{{array[y_i][x_i]}}</div>
        </div>
    </div> -->

    <div class="border o_box view_box">
        <div v-for="(y, y_i) in viewArray" :key="y_i" class="my_border">
            <div
                v-for="(x, x_i) in y"
                :key="x_i"
                @click.left="demining(y_i, x_i, 'left')"
                @click.right="demining(y_i, x_i, 'right')"
                :class="{
                    'init_box': ['√', '~'].includes(viewArray[y_i][x_i]),
                    'number_box': viewArray[y_i][x_i] > 0 && viewArray[y_i][x_i] < 9,
                    'safety_box': viewArray[y_i][x_i] === '-',
                    'danger_box': ['X', '雷'].includes(viewArray[y_i][x_i]),
                }"
                class="border y_box"
            >
                <span v-if="['-', '~'].includes(viewArray[y_i][x_i])"></span>
                <span v-else-if="viewArray[y_i][x_i] === '√'">
                    <svg width="12" height="12" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><rect width="48" height="48" fill="white" fill-opacity="0.01"/><path d="M8 44H12H16" stroke="#f33c3c" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 44V4" stroke="#f33c3c" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M40 6H12V22H40L36 14L40 6Z" fill="none" stroke="#f33c3c" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </span>
                <span v-else-if="viewArray[y_i][x_i] === 'X'">
                    <svg width="12" height="12" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><rect width="48" height="48" fill="white" fill-opacity="0.01"/><path fill-rule="evenodd" clip-rule="evenodd" d="M24 44C35.0457 44 44 35.0457 44 24C44 12.9543 35.0457 4 24 4C12.9543 4 4 12.9543 4 24C4 35.0457 12.9543 44 24 44Z" stroke="#f33c3c" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path fill-rule="evenodd" clip-rule="evenodd" d="M24 34C29.5228 34 34 29.5228 34 24C34 18.4772 29.5228 14 24 14C18.4772 14 14 18.4772 14 24C14 29.5228 18.4772 34 24 34Z" stroke="#f33c3c" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M24 4V44" stroke="#f33c3c" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 24L18 24.0083" stroke="#f33c3c" stroke-width="4" stroke-linecap="round"/><path d="M4 24.0083L44 24.0083" stroke="#f33c3c" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </span>
                <span v-else-if="viewArray[y_i][x_i] === '雷'">
                    <svg width="12" height="12" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><rect width="48" height="48" fill="white" fill-opacity="0.01"/><path fill-rule="evenodd" clip-rule="evenodd" d="M24 44C35.0457 44 44 35.0457 44 24C44 12.9543 35.0457 4 24 4C12.9543 4 4 12.9543 4 24C4 35.0457 12.9543 44 24 44Z" stroke="#000000" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path fill-rule="evenodd" clip-rule="evenodd" d="M24 34C29.5228 34 34 29.5228 34 24C34 18.4772 29.5228 14 24 14C18.4772 14 14 18.4772 14 24C14 29.5228 18.4772 34 24 34Z" stroke="#000000" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M24 4V44" stroke="#000000" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 24L18 24.0083" stroke="#000000" stroke-width="4" stroke-linecap="round"/><path d="M4 24.0083L44 24.0083" stroke="#000000" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </span>
                <span v-else>{{viewArray[y_i][x_i]}}</span>
            </div>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { reduce } from 'lodash'
import { onMounted, reactive, ref, Ref } from 'vue'
const array: Ref<Array<any>> = ref([]) // 数据地图
const viewArray: Ref<Array<any>> = ref([]) // 遮罩视图
let mineFieldNumber = ref(10) // 雷数
let mineField: Ref<Array<any>> = ref([]) // 雷区
let relax: Ref<String> = ref('-') // 显示状态
/**
 * '~' 未选中 / 未定义区域
 * '0' 中心区域
 * '1-8' 边缘雷区标识
 * '9' 雷
 * '*' 标记雷区 - 只能在 '~' 上标记
 * 'X' 选中的雷区（踩雷了）
 * '雷' 显示其余雷区
 * '-' 绝对安全区
 */

onMounted(() => {
    initArray()
    // console.log(array.value)

    document.oncontextmenu = function (e) {
        return false
    }
})

const initArray = () => {
    array.value = JSON.parse(JSON.stringify(new Array(10).fill(new Array(10).fill('0'))))
    viewArray.value = JSON.parse(JSON.stringify(new Array(10).fill(new Array(10).fill('~'))))
    mineField.value = []
    relax.value = '-'
}

    /**
     * 雷区字典
     * @x 横坐标
     * @y 纵坐标
     * 返回周边有效宫格数组
     */
    let dangerDicionary = (x: number, y: number) => {
        // 周边公式
        let dangerZone = [
            ['-', '+'],
            ['*', '+'],
            ['+', '+'],
            ['-', '*'],
            ['+', '*'],
            ['-', '-'],
            ['*', '-'],
            ['+', '-']
        ]
        let aimList: any[] = []
        dangerZone.forEach(item => {
            let dz_x = eval(`${x}${item[0]}${1}`)
            let dz_y = eval(`${y}${item[1]}${1}`)
            if (dz_x > -1 && dz_x < 10 && dz_y > -1 && dz_y < 10) {
                aimList.push([dz_x, dz_y])
            }
        })

        // console.log(aimList)
        return aimList
    }

// 开始，随机生成
const start = () => {
    initArray()

    /**
     * 去重方法
     * @arr 目标数组
     * @aim 查重目标值
     * 若查询长度 大于 则存在重复
     */
    let deWeight = (arr: Array<any>, aim: any) => {
        let newArr = arr.filter(item => {
            return JSON.stringify(item) === JSON.stringify(aim)
        })

        if (newArr.length > 1) {
            // 当前重复
            let newAim = [Math.floor(Math.random() * 10), Math.floor(Math.random() * 10)]
            mineField.value.splice(mineField.value.length - 1, 1, newAim)
            deWeight(mineField.value, newAim)
        } else {
            return
        }
    }

    Array(Number(mineFieldNumber.value)).fill(null).forEach((item, i) => {
        mineField.value[i] = [Math.floor(Math.random() * 10), Math.floor(Math.random() * 10)]
        // 去重
        deWeight(mineField.value, mineField.value[i])
    })
    
    /**
     * 将雷 mineField 放入 array 地图中
     */
    mineField.value.forEach(item => {
        array.value[item[0]][item[1]] = '9'
    })

    /**
     * 填充雷区周围
     * 有雷 1~8
     */
    
    const ta = JSON.parse(JSON.stringify(array.value))
    mineField.value.forEach(item => {
        // 雷坐标
        let x = item[1]
        let y = item[0]

        // 获取雷区周边坐标 (非雷)
        let s_danger_list = dangerDicionary(x, y).filter(v => ta[v[1]][v[0]] !== '9')
        
        // 通过雷区标识确定当前点位的数值
        s_danger_list.forEach(s_item => {
            // 获取周围坐标
            let d_danger_number = dangerDicionary(s_item[0], s_item[1]).filter(v => ta[v[1]][v[0]] == '9').length
            array.value[s_item[1]][s_item[0]] = d_danger_number.toString()
        })
    })
}

// 扫雷
const demining = (y: number, x: number, event: string) => {
    if (relax.value !== '-') {
        return
    }
    // console.log(x, y, event)
    const aimArray = JSON.parse(JSON.stringify(array.value))

    // 方法区 ----------------------------------------------------
    const changeView = (x: number, y: number) => {
        // 如果为雷
        switch (aimArray[y][x]) {
            case '9': {
                /**
                 * 将雷 mineField 放入 viewArray 地图中
                 */
                mineField.value.forEach(item => {
                    viewArray.value[item[0]][item[1]] = '雷'
                })
                /**
                 * 标记当前选中雷区
                 */
                viewArray.value[y][x] = 'X'
                /**
                 * 修改当前进行状态
                 */
                relax.value = 'おまえは、もう死んでいる'
                break
            }
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8': {
                /**
                 * 展示周围雷区数字
                 */
                viewArray.value[y][x] = aimArray[y][x]
                break
            }
            case '0': {
                /**
                 * 周围无雷，十字扩散算法
                 */
                changeZero([[x, y]])
                break
            }
            
        }
    }
    
    // 十字扩散算法
    const changeZero = (list: Array<any>) => {
        // console.log(list)
        let aimArray = JSON.parse(JSON.stringify(array.value))
        /**
         * 1. 将目前窗格修改为安全区 '-'
         * 2. 确认是否延展
         */
        let extensionFun = [ // 延展公式
            ['*', '+'],
            ['-', '*'],
            ['+', '*'],
            ['*', '-']
        ]
        let extensionList: any[] = [] // 蔓延区域

        list.forEach(L_item => {
             viewArray.value[L_item[1]][L_item[0]] = '-' 
        })

        extensionFun.forEach(ex_item => {
            list.forEach(l_item => {
                let dz_x = eval(`${l_item[0]}${ex_item[0]}${1}`)
                let dz_y = eval(`${l_item[1]}${ex_item[1]}${1}`)
                if (dz_x > -1 && dz_x < 10 && dz_y > -1 && dz_y < 10) { // 确认无越界
                    if (aimArray[dz_y][dz_x] === '0') { // 为0继续延展
                        let isFind = extensionList.find((v) => { // 确认当前扩展列表有无重复
                            return v[0] === dz_x && v[1] === dz_y
                        })

                        if (!isFind && viewArray.value[dz_y][dz_x] === '~') { // 确保已标记选择的方格不会进入延展列表
                        extensionList.push([dz_x, dz_y])
                        }
                    } else if (aimArray[dz_y][dz_x] > 0 && aimArray[dz_y][dz_x] < 9) { // 显示周围雷数
                        viewArray.value[dz_y][dz_x] = aimArray[dz_y][dz_x]
                    }
                }
            })
        })
        if (extensionList.length !== 0) {
            changeZero(extensionList)
        }
        // console.log(extensionList, 'extensionList')
    }

    // 逻辑区 ----------------------------------------------------
    // 鼠标左键事件 ----------------------------------------------
    if (event === 'left') {
        // 只有未点击部分 `~` 可以点击
        if (viewArray.value[y][x] === '~') {
            // 修改根据数据地图修改视图地图
            changeView(x, y)
        }
    }

    // 鼠标又键事件 ----------------------------------------------
    if (event === 'right') {
        // 若是 未点击部分 `~`， 则切换为 '√' 标记是雷， 若为 '√' 则切换为'~'
        if (viewArray.value[y][x] === '~') {
            viewArray.value[y][x] = '√'
        } else if (viewArray.value[y][x] === '√') {
            viewArray.value[y][x] = '~'
        }

        // 若为数字，且四周红旗数等于该数字， 则模拟点击其余'~'方格
        if (viewArray.value[y][x] > 0 && viewArray.value[y][x] < 9) {
            let isFlag = dangerDicionary(x, y).filter(v => {
                return viewArray.value[v[1]][v[0]] === '√'
            })
            let doIt = dangerDicionary(x, y).filter(v => {
                return viewArray.value[v[1]][v[0]] === '~'
            })
            if (isFlag.length === Number(viewArray.value[y][x])) {
                doIt.forEach(v => {
                    demining(v[1], v[0], 'left')
                })
            }
            console.log(isFlag, doIt)
        }
    }

    // 判断是否完成扫雷 mineField 与 viewArray 剩余长度 长度， 内容完全相同
    let remainList: any[] = []
    viewArray.value.forEach((v_item_y, y) => {
        v_item_y.forEach((v_item_x: any, x: any) => {
            if (['~', '√'].includes(v_item_x)) {
                remainList.push([y, x])
            }
        })
    })
    
    let tempmineField = JSON.parse(JSON.stringify(mineField.value))
    if (tempmineField.length === remainList.length) { // 首先需要长度相同
        let isSuccess = tempmineField.every((item: any) => {
            return remainList.some((v) => {
                return v[0] === item[0] && v[1] === item[1]
            })
        })

        if (isSuccess) {
            relax.value = 'CONGRATULATION!'
        }
    }
}
</script>

<style scoped>
.border {
    border: 1px solid lightgray;
}

.my_border {
    height: 24px;
    display: flex;
    align-items: flex-start;
}

.o_box {
    box-sizing: border-box;
    width: 242px;
}

.y_box {
    display: inline-block;
    width: 24px;
    height: 24px;
    text-align: center;
    line-height: 24px;
}
.view_box {
    cursor: pointer;
}

.init_box {
    background-color: lightslategray;
}

.number_box {
    background-color: lightsalmon;
}

.safety_box {
    background-color: lightcyan;
}

.danger_box {
    background-color: lightgray;
}
</style>