<template>
    <a-breadcrumb>
        <a-breadcrumb-item>Home</a-breadcrumb-item>
        <a-breadcrumb-item>{{dictionary[tab]}}</a-breadcrumb-item>
  </a-breadcrumb>
</template>

<script lang="ts" setup>
import {reactive} from 'vue'
interface Props {
  tab?: string
}

const props = withDefaults(defineProps<Props>(), {
    tab: '1'
})

const dictionary = reactive({
    '1': 'Table',
    '2': 'Form',
    '3': 'Demo',
    '4': 'Demo'
})
</script>

<style scoped>

</style>