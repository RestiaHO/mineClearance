<template>
  <div style="width: 100%; height: 100%">
    <MenuList/>
  </div>
</template>

<script setup lang="ts">
import { defineAsyncComponent, ref } from 'vue'

const MenuList: any = defineAsyncComponent(() => import('./menuList.vue'))

defineProps<{ msg: string }>()

const count = ref(0)
</script>

<style scoped>
a {
  color: #42b983;
}

label {
  margin: 0 0.5em;
  font-weight: bold;
}

code {
  background-color: #eee;
  padding: 2px 4px;
  border-radius: 4px;
  color: #304455;
}
</style>
